"""
Broker Reconciliation - Startup position/order recovery protocol.

CRITICAL PURPOSE:
Prevents position loss after crashes/restarts by syncing with broker truth.

RECONCILIATION PROTOCOL:
1. Fetch all positions from broker
2. Fetch all pending orders from broker
3. Compare with local state (OrderMachine, PositionStore)
4. Resolve discrepancies (broker = source of truth)
5. Log all discrepancies for audit

WHEN TO RUN:
- MANDATORY on every startup before trading
- Optional: Periodic reconciliation during trading
- After network reconnection

PATCH 3: Fixed broker method calls to match actual API.

Based on IBKR's reconciliation protocol with enhanced safety.
"""

from typing import List, Dict, Tuple, Optional
from decimal import Decimal
from datetime import datetime, timezone
from dataclasses import dataclass
import logging

from core.state.order_machine import OrderStateMachine
from core.state.position_store import PositionStore, Position

logger = logging.getLogger(__name__)


# ============================================================================
# DISCREPANCY TYPES
# ============================================================================

@dataclass
class Discrepancy:
    """Represents a mismatch between local and broker state."""
    type: str  # "missing_position", "extra_position", "missing_order", "extra_order", "quantity_mismatch"
    symbol: str
    local_value: Optional[str]
    broker_value: Optional[str]
    resolution: str  # Action taken to resolve
    timestamp: datetime


# ============================================================================
# BROKER RECONCILER
# ============================================================================

class BrokerReconciler:
    """
    Reconciles local state with broker truth.
    
    INVARIANTS:
    - Broker is ALWAYS source of truth
    - All discrepancies are logged
    - Reconciliation is atomic (all-or-nothing)
    - Must complete successfully before trading
    
    Usage:
        reconciler = BrokerReconciler(
            order_machine=order_machine,
            position_store=position_store,
            broker_connector=alpaca_connector
        )
        
        # On startup (MANDATORY)
        discrepancies = reconciler.reconcile_startup()
        if discrepancies:
            logger.warning(f"Found {len(discrepancies)} discrepancies")
        
        # Periodic (optional)
        discrepancies = reconciler.reconcile_periodic()
    """
    
    def __init__(
        self,
        order_machine: OrderStateMachine,
        position_store: PositionStore,
        broker_connector  # AlpacaConnector or similar
    ):
        """
        Initialize reconciler.
        
        Args:
            order_machine: Local order state
            position_store: Local position state
            broker_connector: Broker API connector
        """
        self.order_machine = order_machine
        self.position_store = position_store
        self.broker = broker_connector
        
        self._reconciliation_count = 0
        self._total_discrepancies = 0
        
        logger.info("BrokerReconciler initialized")
    
    # ========================================================================
    # STARTUP RECONCILIATION (MANDATORY)
    # ========================================================================
    
    def reconcile_startup(self) -> List[Discrepancy]:
        """
        Perform full reconciliation on startup.
        
        CRITICAL: MUST be called before any trading occurs.
        
        Returns:
            List of discrepancies found and resolved
        """
        logger.info("[RECONCILIATION] Starting startup reconciliation...")
        
        discrepancies = []
        
        # Reconcile positions
        position_discrepancies = self._reconcile_positions()
        discrepancies.extend(position_discrepancies)
        
        # Reconcile orders (NOW ENABLED)
        order_discrepancies = self._reconcile_orders()
        discrepancies.extend(order_discrepancies)
        
        # Update stats
        self._reconciliation_count += 1
        self._total_discrepancies += len(discrepancies)
        
        if discrepancies:
            logger.warning(
                f"[RECONCILIATION] Found {len(discrepancies)} discrepancies:\n" +
                "\n".join(f"  - {d.type}: {d.symbol} ({d.resolution})" for d in discrepancies)
            )
        else:
            logger.info("[RECONCILIATION] No discrepancies found - state is clean")
        
        return discrepancies
    
    # ========================================================================
    # POSITION RECONCILIATION
    # ========================================================================
    
    def _reconcile_positions(self) -> List[Discrepancy]:
        """
        Reconcile positions with broker.
        
        STEPS:
        1. Fetch broker positions
        2. Fetch local positions
        3. Compare symbol-by-symbol
        4. Resolve: Add missing, remove extra, update quantities
        
        Returns:
            List of position discrepancies
        """
        discrepancies = []
        
        # Fetch broker positions
        try:
            broker_positions = self._fetch_broker_positions()
        except Exception as e:
            logger.error(f"Failed to fetch broker positions: {e}", exc_info=True)
            return discrepancies
        
        # Fetch local positions
        local_positions = self.position_store.get_all_positions()
        
        # Create lookup maps
        broker_map = {pos['symbol']: pos for pos in broker_positions}
        local_map = {pos.symbol: pos for pos in local_positions}
        
        # Find all symbols
        all_symbols = set(broker_map.keys()) | set(local_map.keys())
        
        for symbol in all_symbols:
            broker_pos = broker_map.get(symbol)
            local_pos = local_map.get(symbol)
            
            if broker_pos and not local_pos:
                # Missing position locally - ADD IT
                discrepancy = self._add_missing_position(broker_pos)
                discrepancies.append(discrepancy)
            
            elif local_pos and not broker_pos:
                # Extra position locally - REMOVE IT
                discrepancy = self._remove_extra_position(local_pos)
                discrepancies.append(discrepancy)
            
            elif broker_pos and local_pos:
                # Both exist - CHECK QUANTITIES
                broker_qty = Decimal(str(broker_pos['quantity']))
                local_qty = local_pos.quantity
                
                if broker_qty != local_qty:
                    discrepancy = self._fix_quantity_mismatch(
                        symbol, local_qty, broker_qty
                    )
                    discrepancies.append(discrepancy)
        
        return discrepancies
    
    def _add_missing_position(self, broker_pos: dict) -> Discrepancy:
        """Add position that exists at broker but not locally."""
        symbol = broker_pos['symbol']
        quantity = Decimal(str(broker_pos['quantity']))
        avg_price = Decimal(str(broker_pos['avg_entry_price']))
        side = "LONG" if quantity > 0 else "SHORT"
        
        logger.warning(
            f"[RECONCILE] Adding missing position: "
            f"{symbol} {quantity} @ ${avg_price}"
        )
        
        # Add to position store
        self.position_store.open_position(
            symbol=symbol,
            quantity=abs(quantity),
            entry_price=avg_price,
            side=side,
            strategy="reconciled",  # Mark as reconciled
            stop_loss=None,
            take_profit=None
        )
        
        return Discrepancy(
            type="missing_position",
            symbol=symbol,
            local_value=None,
            broker_value=f"{quantity} @ ${avg_price}",
            resolution="added_to_local",
            timestamp=datetime.now(timezone.utc)
        )
    
    def _remove_extra_position(self, local_pos: Position) -> Discrepancy:
        """Remove position that exists locally but not at broker."""
        logger.warning(
            f"[RECONCILE] Removing extra position: "
            f"{local_pos.symbol} {local_pos.quantity} "
            f"(exists locally but not at broker)"
        )
        
        # Close position in store
        self.position_store.close_position(
            position_id=local_pos.position_id,
            exit_price=local_pos.entry_price,  # No realized P&L
            close_reason="reconciliation_cleanup"
        )
        
        return Discrepancy(
            type="extra_position",
            symbol=local_pos.symbol,
            local_value=f"{local_pos.quantity} @ ${local_pos.entry_price}",
            broker_value=None,
            resolution="removed_from_local",
            timestamp=datetime.now(timezone.utc)
        )
    
    def _fix_quantity_mismatch(
        self,
        symbol: str,
        local_qty: Decimal,
        broker_qty: Decimal
    ) -> Discrepancy:
        """Fix quantity mismatch (broker is truth)."""
        logger.warning(
            f"[RECONCILE] Quantity mismatch for {symbol}: "
            f"local={local_qty}, broker={broker_qty} (updating to broker value)"
        )
        
        # Get position and update quantity
        position = self.position_store.get_position(symbol)
        if position:
            # Close old position
            self.position_store.close_position(
                position_id=position.position_id,
                exit_price=position.entry_price,
                close_reason="reconciliation_quantity_fix"
            )
            
            # Reopen with correct quantity
            side = "LONG" if broker_qty > 0 else "SHORT"
            self.position_store.open_position(
                symbol=symbol,
                quantity=abs(broker_qty),
                entry_price=position.entry_price,
                side=side,
                strategy=position.strategy,
                stop_loss=position.stop_loss,
                take_profit=position.take_profit
            )
        
        return Discrepancy(
            type="quantity_mismatch",
            symbol=symbol,
            local_value=str(local_qty),
            broker_value=str(broker_qty),
            resolution="updated_to_broker_value",
            timestamp=datetime.now(timezone.utc)
        )
    
    # ========================================================================
    # ORDER RECONCILIATION
    # ========================================================================
    
    def _reconcile_orders(self) -> List[Discrepancy]:
        """
        Reconcile pending orders with broker.
        
        STEPS:
        1. Fetch broker pending orders
        2. Fetch local pending orders
        3. Compare order-by-order
        4. Resolve: Cancel extra local orders, add missing orders
        
        Returns:
            List of order discrepancies
        """
        discrepancies = []
        
        # Fetch broker pending orders
        try:
            broker_orders = self._fetch_broker_pending_orders()
        except Exception as e:
            logger.error(f"Failed to fetch broker orders: {e}", exc_info=True)
            return discrepancies
        
        # Fetch local pending orders
        local_orders = self.order_machine.get_pending_orders()
        
        # Create lookup maps (by broker_order_id)
        broker_map = {order['id']: order for order in broker_orders}
        local_map = {order.broker_order_id: order for order in local_orders if order.broker_order_id}
        
        # Find all order IDs
        all_order_ids = set(broker_map.keys()) | set(local_map.keys())
        
        for order_id in all_order_ids:
            broker_order = broker_map.get(order_id)
            local_order = local_map.get(order_id)
            
            if broker_order and not local_order:
                # Missing order locally - LOG WARNING
                # (We don't automatically add broker orders to local state)
                discrepancy = Discrepancy(
                    type="missing_order",
                    symbol=broker_order['symbol'],
                    local_value=None,
                    broker_value=f"{broker_order['qty']} {broker_order['side']}",
                    resolution="logged_only",
                    timestamp=datetime.now(timezone.utc)
                )
                discrepancies.append(discrepancy)
                logger.warning(
                    f"[RECONCILE] Found broker order not in local state: "
                    f"{order_id} {broker_order['symbol']}"
                )
            
            elif local_order and not broker_order:
                # Extra order locally - CANCEL IT
                discrepancy = self._cancel_extra_order(local_order)
                discrepancies.append(discrepancy)
        
        return discrepancies
    
    def _cancel_extra_order(self, local_order) -> Discrepancy:
        """Cancel order that exists locally but not at broker."""
        logger.warning(
            f"[RECONCILE] Cancelling extra order: "
            f"{local_order.order_id} {local_order.symbol} "
            f"(exists locally but not at broker)"
        )
        
        # Transition to CANCELLED
        try:
            from core.state.order_machine import OrderStatus
            self.order_machine.transition(
                order_id=local_order.order_id,
                from_state=local_order.state,
                to_state=OrderStatus.CANCELLED,
                reason="reconciliation_cleanup"
            )
        except Exception as e:
            logger.error(f"Failed to cancel order {local_order.order_id}: {e}")
        
        return Discrepancy(
            type="extra_order",
            symbol=local_order.symbol,
            local_value=f"{local_order.quantity} {local_order.side}",
            broker_value=None,
            resolution="cancelled_locally",
            timestamp=datetime.now(timezone.utc)
        )
    
    # ========================================================================
    # BROKER API CALLS
    # ========================================================================
    
    def _fetch_broker_positions(self) -> List[dict]:
        """
        Fetch all positions from broker.
        
        PATCH 3: Fixed to call get_positions() instead of get_all_positions()
        PATCH 3: Fixed attribute access for Position objects
        
        Returns:
            List of position dicts with keys:
            - symbol, quantity, avg_entry_price, market_value
        """
        # PATCH 3: Changed from get_all_positions() to get_positions()
        positions = self.broker.get_positions()
        
        result = []
        for pos in positions:
            result.append({
                'symbol': pos.symbol,
                'quantity': float(pos.quantity),  # PATCH 3: Position uses .quantity (not .qty)
                'avg_entry_price': float(pos.entry_price),  # PATCH 3: Position uses .entry_price
                'market_value': float(pos.unrealized_pnl) if pos.unrealized_pnl else 0.0  # PATCH 3: Approximate
            })
        
        logger.debug(f"[RECONCILE] Fetched {len(result)} positions from broker")
        return result
    
    def _fetch_broker_pending_orders(self) -> List[dict]:
        """
        Fetch all pending orders from broker.
        
        Returns:
            List of order dicts with keys:
            - id, symbol, qty, side, status
        """
        orders = self.broker.get_orders(status='open')
        
        result = []
        for order in orders:
            result.append({
                'id': str(order.id),
                'symbol': order.symbol,
                'qty': float(order.qty),
                'side': order.side,
                'status': order.status
            })
        
        logger.debug(f"[RECONCILE] Fetched {len(result)} pending orders from broker")
        return result
    
    # ========================================================================
    # PERIODIC RECONCILIATION (OPTIONAL)
    # ========================================================================
    
    def reconcile_periodic(self) -> List[Discrepancy]:
        """
        Perform periodic reconciliation during trading.
        
        Lighter-weight than startup (only checks positions, not orders).
        
        Returns:
            List of discrepancies
        """
        logger.info("[RECONCILIATION] Starting periodic reconciliation...")
        
        discrepancies = self._reconcile_positions()
        
        self._reconciliation_count += 1
        self._total_discrepancies += len(discrepancies)
        
        if discrepancies:
            logger.warning(
                f"[RECONCILIATION] Periodic check found {len(discrepancies)} discrepancies"
            )
        
        return discrepancies
    
    # ========================================================================
    # STATISTICS
    # ========================================================================
    
    def get_stats(self) -> dict:
        """Get reconciliation statistics."""
        return {
            'reconciliation_count': self._reconciliation_count,
            'total_discrepancies': self._total_discrepancies,
            'avg_discrepancies_per_run': (
                self._total_discrepancies / self._reconciliation_count
                if self._reconciliation_count > 0
                else 0
            )
        }
