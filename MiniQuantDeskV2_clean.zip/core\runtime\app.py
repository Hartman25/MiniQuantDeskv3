"""
Runtime Application - Main trading loop for paper and live trading.

ARCHITECTURE:
- Single unified runner for both paper and live modes
- Event-driven with configurable cycle interval
- Loads strategies from config
- Enforces data validation (anti-lookahead)
- Routes signals through risk gate
- Handles graceful shutdown

PATCH 3: Added live mode halt on reconciliation failures.

Based on LEAN's Algorithm.Run() with enhanced safety.
"""

from __future__ import annotations

import signal
import time
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Dict, List, Optional
from collections import deque

import pandas as pd

from core.di.container import Container
from core.brokers import AlpacaBrokerConnector, BrokerOrderSide
from core.execution.engine import OrderExecutionEngine
from core.data.validator import DataValidator
from core.data.contract import MarketDataContract
from core.logging import get_logger, LogStream
from core.risk.manager import RiskManager


logger = get_logger(LogStream.SYSTEM)


@dataclass
class RunOptions:
    config_path: Path
    mode: str  # "paper" or "live"
    run_interval_s: int = 60


def _ensure_strategy_registry_bootstrapped(container: Container) -> None:
    """
    Register built-in strategies into StrategyRegistry.

    Strategies must be registered before instantiation from config.
    Registry uses class.__name__ as the key.
    """
    registry = container.get_strategy_registry()

    # Register VWAP mean reversion strategy
    try:
        from strategies.vwap_mean_reversion import VWAPMeanReversion
        registry.register(VWAPMeanReversion)

        # Register Micro VWAP mean reversion strategy
        from strategies.vwap_micro_mean_reversion import VWAPMicroMeanReversion
        registry.register(VWAPMicroMeanReversion)
    except ValueError:
        # Already registered
        pass
    except Exception as e:
        raise RuntimeError(f"Failed to register built-in strategies: {e}") from e


def _df_to_contracts(symbol: str, df: pd.DataFrame) -> List[MarketDataContract]:
    """Convert provider DataFrame to MarketDataContract list."""
    bars: List[MarketDataContract] = []
    if df is None or df.empty:
        return bars

    for ts, row in df.iterrows():
        try:
            bars.append(
                MarketDataContract(
                    symbol=symbol,
                    timestamp=ts.to_pydatetime() if hasattr(ts, "to_pydatetime") else ts,
                    open=Decimal(str(row["open"])),
                    high=Decimal(str(row["high"])),
                    low=Decimal(str(row["low"])),
                    close=Decimal(str(row["close"])),
                    volume=int(row["volume"]) if "volume" in row and pd.notna(row["volume"]) else None,
                    provider="alpaca",
                )
            )
        except Exception:
            continue

    return bars


def _to_dt(ts) -> datetime:
    """Best-effort normalize timestamps to tz-aware UTC datetime."""
    if isinstance(ts, datetime):
        if ts.tzinfo is None:
            return ts.replace(tzinfo=timezone.utc)
        return ts.astimezone(timezone.utc)
    # Fallback: treat as epoch seconds
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc)
    except Exception:
        return datetime.now(tz=timezone.utc)


def run(opts: RunOptions) -> None:
    """Run the trading app."""
    container = Container()
    container.init_from_file(opts.config_path)

    cfg = container.get_config()

    paper = opts.mode == "paper"
    cfg.broker.paper_trading = paper

    broker = AlpacaBrokerConnector(
        api_key=cfg.broker.api_key,
        api_secret=cfg.broker.api_secret,
        paper=paper,
    )
    container.set_broker_connector(broker)

    # Register strategies
    _ensure_strategy_registry_bootstrapped(container)

    # Start services
    container.start()

    # -------------------------------------------------------------------
    # NEW: Get centralized protections from container
    # -------------------------------------------------------------------
    protections = container.get_protections()
    logger.info("Using unified ProtectionManager from container (5 protections active)")

    # ===============================================================
    # LOAD STRATEGIES
    # ===============================================================
    registry = container.get_strategy_registry()
    lifecycle = container.get_strategy_lifecycle()
    exec_engine: OrderExecutionEngine = container.get_order_execution_engine()
    risk_manager: RiskManager = container.get_risk_manager()
    data_validator: DataValidator = container.get_data_validator()

    # Load strategies from config
    all_symbols: List[str] = []
    for strat_cfg in cfg.strategies.enabled:
        s = registry.create(
            name=strat_cfg.name,
            config=strat_cfg.config,
            symbols=strat_cfg.symbols,
            timeframe=strat_cfg.timeframe,
        )
        lifecycle.add_strategy(s)
        lifecycle.start_strategy(s.name)
        for sym in s.symbols:
            if sym not in all_symbols:
                all_symbols.append(sym)

    # ===============================================================
    # SIGNAL HANDLING
    # ===============================================================
    class _State:
        running = True

    state = _State()

    def _stop(_sig, _frame):
        state.running = False

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    logger.info(f"Starting runtime loop mode={opts.mode} symbols={all_symbols}")
    
    # NEW: Orphan check counter (check every 10 cycles = 10 minutes)
    cycle_count = 0
    orphan_check_interval = 10  # cycles

    while state.running:
        try:
            # Get account info
            acct = broker.get_account_info()
            account_value = Decimal(str(acct.get("portfolio_value", "0")))
            buying_power = Decimal(str(acct.get("buying_power", "0")))

            for symbol in all_symbols:
                # Determine timeframe/lookback from first strategy using this symbol
                timeframe = "1Min"
                lookback = 120

                df = broker.get_bars(symbol=symbol, timeframe=timeframe, limit=lookback)
                bars = _df_to_contracts(symbol, df)

                # ============================================================
                # CRITICAL: VALIDATE BARS (anti-lookahead)
                # ============================================================
                data_validator.validate_bars(bars=bars, timeframe=timeframe)

                # Only use the latest COMPLETE bar
                bar = bars[-1]
                if not bar.is_complete(timeframe):
                    continue

                # ROUTE TO STRATEGIES
                signals = lifecycle.on_bar(bar)

                for sig in signals:
                    sig_symbol = sig.get("symbol", symbol)
                    side_str = str(sig.get("side", "BUY")).upper()
                    qty = Decimal(str(sig.get("quantity", "0")))
                    if qty <= 0:
                        continue

                    # ========================================================
                    # PROTECTION MANAGER (unified circuit breakers)
                    # ========================================================
                    sig_price = Decimal(str(sig.get("price", bar.close)))
                    sig_strategy = sig.get("strategy", "UNKNOWN")
                    
                    # Check protections (TimeWindow, Volatility, Stoploss, Drawdown, Cooldown)
                    prot_result = protections.check(
                        symbol=sig_symbol,
                        current_trades=None,  # TODO: Pass actual trades from PositionStore
                        completed_trades=None  # TODO: Pass recent completed trades
                    )
                    
                    if prot_result.is_protected:
                        logger.warning(
                            f"PROTECTION_BLOCK: {sig_symbol} {side_str} qty={qty} reason={prot_result.reason}",
                            extra={
                                "strategy": sig_strategy,
                                "symbol": sig_symbol,
                                "protection_reason": prot_result.reason,
                                "protected_until": prot_result.until.isoformat() if prot_result.until else None,
                            },
                        )
                        continue

                    broker_side = (
                        BrokerOrderSide.BUY
                        if side_str in ("BUY", "LONG")
                        else BrokerOrderSide.SELL
                    )

                    # Risk manager pre-trade validation
                    risk = risk_manager.validate_trade(
                        symbol=sig_symbol,
                        quantity=qty,
                        side=broker_side,
                        price=sig_price,
                        account_value=account_value,
                        buying_power=buying_power,
                        strategy=sig_strategy,
                    )

                    if not risk.approved:
                        logger.warning(
                            f"RISK_BLOCK: {sig_symbol} {side_str} qty={qty} reason={risk.reason}",
                            extra=risk.to_dict(),
                        )
                        continue

                    # Submit order
                    internal_id = f"{sig_strategy}-{uuid.uuid4().hex[:10]}"
                    stop_loss = sig.get("stop_loss")
                    take_profit = sig.get("take_profit")
                    if stop_loss is not None:
                        stop_loss = Decimal(str(stop_loss))
                    if take_profit is not None:
                        take_profit = Decimal(str(take_profit))

                    broker_order_id = exec_engine.submit_market_order(
                        internal_order_id=internal_id,
                        symbol=sig_symbol,
                        quantity=qty,
                        side=broker_side,
                        strategy=sig_strategy,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                    )
            
            # NEW: Periodic orphan order check (every 10 cycles = 10 minutes)
            cycle_count += 1
            if cycle_count >= orphan_check_interval:
                cycle_count = 0
                
                try:
                    # Get order tracker from container
                    order_tracker = container.get_order_tracker()
                    
                    # Get broker's open orders
                    broker_orders_list = broker.get_orders()
                    broker_orders = {order.id: order for order in broker_orders_list}
                    
                    # Check for orphans (broker has, we don't)
                    orphans = order_tracker.get_orphaned_orders(broker_orders)
                    if orphans:
                        logger.error(
                            f"ORPHAN ORDERS DETECTED: {len(orphans)} orders",
                            extra={
                                "orphan_broker_ids": orphans,
                                "action": "Manual review required"
                            }
                        )
                    
                    # Check for shadows (we have, broker doesn't)
                    shadows = order_tracker.get_shadow_orders(broker_orders)
                    if shadows:
                        logger.error(
                            f"SHADOW ORDERS DETECTED: {len(shadows)} orders",
                            extra={
                                "shadow_client_ids": shadows,
                                "action": "Manual review required"
                            }
                        )
                    
                    if not orphans and not shadows:
                        logger.info("Orphan check: No drift detected")
                
                except Exception as e:
                    logger.error(f"Orphan check failed: {e}", exc_info=True)

            time.sleep(opts.run_interval_s)

        except Exception as e:
            logger.exception(f"Runtime loop error: {e}")
            time.sleep(opts.run_interval_s)

    logger.info("Runtime loop stopped")
