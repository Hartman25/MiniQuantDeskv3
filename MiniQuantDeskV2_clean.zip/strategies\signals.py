"""
Typed strategy signal objects.

Why:
- Dict signals are fragile (silent key typos)
- Strong typing improves validation + testability
- Still supports legacy dict consumption via to_dict()

This module intentionally stays small and dependency-free.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, Dict, Any, Literal


Side = Literal["BUY", "SELL"]


@dataclass(frozen=True)
class StrategySignal:
    """
    Strategy output = intent to trade (NOT an order).

    Notes:
    - side is BUY/SELL (runner/execution decides how to route)
    - quantity is Decimal to support fractional shares
    - stop_loss / take_profit are OPTIONAL prices (not percentages)
    - reason is REQUIRED for auditability
    """
    symbol: str
    side: Side
    quantity: Decimal
    order_type: Literal["MARKET", "LIMIT"] = "MARKET"
    entry_price: Optional[Decimal] = None
    limit_price: Optional[Decimal] = None
    stop_loss: Optional[Decimal] = None
    take_profit: Optional[Decimal] = None
    reason: str = ""
    strategy: str = "UNKNOWN"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol.upper(),
            "side": self.side,
            "quantity": self.quantity,
            "order_type": self.order_type,
            "entry_price": self.entry_price,
            "limit_price": self.limit_price,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "reason": self.reason,
            "strategy": self.strategy,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "StrategySignal":
        return StrategySignal(
            symbol=str(d["symbol"]).upper(),
            side=str(d["side"]).upper(),  # type: ignore
            quantity=Decimal(str(d["quantity"])),
            order_type=str(d.get("order_type", "MARKET")).upper(),  # type: ignore
            entry_price=Decimal(str(d["entry_price"])) if d.get("entry_price") is not None else None,
            limit_price=Decimal(str(d["limit_price"])) if d.get("limit_price") is not None else None,
            stop_loss=Decimal(str(d["stop_loss"])) if d.get("stop_loss") is not None else None,
            take_profit=Decimal(str(d["take_profit"])) if d.get("take_profit") is not None else None,
            reason=str(d.get("reason", "")),
            strategy=str(d.get("strategy", "UNKNOWN")),
        )
